//2. You are given with a number "N", find its cube.sample input 2. output 8.

function myCube(n){
    return(n**3);
}
console.log(myCube(2));