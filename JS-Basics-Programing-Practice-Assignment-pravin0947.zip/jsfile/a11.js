/*11. Given an array of N elements.find the number of occurences of each character and
print it in the decreasing order of occurences, if 2 or more number occurs the same
number of times, print the numbers in decreasing order.*/

let arr = ['4', '4', '3', '3', '8', '7'];
function removeWhiteS(narray){
    let new_set = new Set(narray);
    let new_array = new Array(new_set);
    console.log(new_array);
}
removeWhiteS(arr);