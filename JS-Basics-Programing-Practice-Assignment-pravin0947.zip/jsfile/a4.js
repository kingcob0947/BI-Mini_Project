//4. You will be provided with a number. Print the number of days in the month

function showMonthDays(m){
    if (m <= 12){
        return new Date(2022, m, 0).getDate();
    }
    else{
        console.log("You are welcome in new year!")
    }  
}
console.log(showMonthDays(4));
console.log(showMonthDays(8));