//6. Write a code to get an integer N and print the sum of values from 1 to N.

function sumOfnNumber(n){
    let sum = 0;
    for (let i = 1; i <= n; i++){
        sum = sum + i;
    }
    console.log(sum);
}
sumOfnNumber(10);