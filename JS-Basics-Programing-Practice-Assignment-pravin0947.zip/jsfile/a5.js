//5. You are given with a number **A** i.e. the temperature in Celcius. Write a program to
//convert this into Fahrenheit.

function FahrenheitS(temp){
    let cel = temp;
    let fahre_it = cel * 1.8 + 32;
    let result = cel+'\xB0C is ' + fahre_it + '\xB0F.';
    console.log(result);
}
FahrenheitS(12);
