
// You will be given a number ‘n’

// **Output Description:** ꢀ

// Print the nth number of series

const number = 5;
const findNth = n => {
   let seq = [1], x = 0, y = 0
   for (let i = 0; i < n; i++) {
      let nextX = 2 * seq[x] + 1, nextY = 3 * seq[y] + 1
      if (nextX <= nextY) {
         seq.push(nextX)
         x++
         if (nextX == nextY)
            y++
         } else {
            seq.push(nextY)
            y++
      }
   }
   return seq[n];
}
console.log(findNth(number));