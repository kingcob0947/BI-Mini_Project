//8. \- Let "A" be a string. Remove all the whitespaces and find it's length.

function removeWhiteS(str){
    if (str <= 0){
        console.log("error")
    }
    else{
    let trimstr = str.split(' ').join('');
    console.log(trimstr.length)
    }
}
removeWhiteS("Lorem Ipsum");