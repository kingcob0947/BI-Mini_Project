//7. You are provided with a number "N", Find the Nth term of the series: 1 , 4, 9, 16, 25,36, 49, 64, 81, ..

function findnTerm(n){
    let nth_term = 1;
    if ( n <= 0){
        console.log("Error");
    }
    else{
        for (let i = 1; i <= n; i++){
            nth_term = i * i;
        }
        console.log(nth_term);
    }
}
findnTerm(18);