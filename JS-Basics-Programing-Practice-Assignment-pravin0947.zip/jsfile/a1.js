//1. You are provided with a number, "**N**". Find its factorial. sample input 5, output 120.

function factorialSearch(n) {
  let factor = 1;
  if (n <= 0) {
    console.log("Error");
  }
  else {
    for (i = 1; i <= n; i++) {
      factor = factor * i;
    }
    console.log(factor);
  }
}
factorialSearch(5);
