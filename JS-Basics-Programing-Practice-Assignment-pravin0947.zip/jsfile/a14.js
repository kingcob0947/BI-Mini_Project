/*You are given with an array. Your task is to print the left rotated array after k

opearations. Time:O(n) Extra Space: O(1)

**Input Description:** ꢀ

First line contains two number ‘n’ and ‘k’.Next line contains n space separated

numbers.

**Output Description:** ꢀ

Print the array as mentioned.*/

function rotateArray(arr, n, k){
	let mod = k % n;
	for (let i = 0; i < n; i++)
		console.log((arr[(mod + i) % n]) + " ");
	console.log("\n");
}
let arr = [ 1, 2, 3, 4, 5, 6, 7];
let n = arr.length;
let k = 3;
rotateArray(arr, n, k);
k = 6;
k = 7;


