let num = 5;
factorial = 1;
for (let i = 5; i => num; i--) {
  factorial = i * factorial;
}
console.log(factorial);